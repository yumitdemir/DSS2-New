﻿namespace Forum.Domain.Models
{
    public enum CommentStatus
    {
        Active,
        Closed,
        Suspended,
    }
}
