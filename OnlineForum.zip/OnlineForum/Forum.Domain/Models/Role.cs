﻿namespace Forum.Domain.Models
{
    public enum Role
    {
        User,
        Admin,
    }
}
