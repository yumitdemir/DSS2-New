﻿namespace Forum.Domain.Models
{
    public interface IDomainEntity
    {
        long? Id { get; set; }
    }
}
