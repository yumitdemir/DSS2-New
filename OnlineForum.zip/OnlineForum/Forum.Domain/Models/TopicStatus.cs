﻿namespace Forum.Domain.Models
{
    public enum TopicStatus
    {
        Active,
        Closed,
        Suspended,
    }
}
