﻿namespace Forum.Application.Dto
{
    public class UserShortDto
    {
        public long? Id { get; set; }
        public string? Username { get; set; }
        public string? FullName { get; set; }
    }
}
